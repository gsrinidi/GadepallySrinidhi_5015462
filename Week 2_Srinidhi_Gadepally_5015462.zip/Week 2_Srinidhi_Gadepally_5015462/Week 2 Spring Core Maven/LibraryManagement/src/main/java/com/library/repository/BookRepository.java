package com.library.repository;



public class BookRepository {

    public void doSomething() {
        System.out.println("BookRepository is doing something");
    }
}

