package com.library.repository;



public class BookRepository {

    
    public void performSomeRepositoryAction() {
        System.out.println("Repository is performing some action.");
    }
}