
package com.library.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {

   
    public void performSomeRepositoryAction() {
        System.out.println("Repository is performing some action.");
    }
}
