package InventoryManagementSystem;
	import java.util.HashMap;
	import java.util.Map;

	public class Main {
	    private Map<String, Product> inventory;

	    public Main() {
	        inventory = new HashMap<>();
	    }

	    public void addProduct(Product product) {
	        if (inventory.containsKey(product.getProductId())) {
	            throw new IllegalArgumentException("Product with this ID already exists.");
	        }
	        inventory.put(product.getProductId(), product);
	    }

	    public void updateProduct(String productId, String productName, Integer quantity, Double price) {
	        if (!inventory.containsKey(productId)) {
	            throw new IllegalArgumentException("Product not found.");
	        }
	        Product product = inventory.get(productId);
	        if (productName != null) {
	            product.setProductName(productName);
	        }
	        if (quantity != null) {
	            product.setQuantity(quantity);
	        }
	        if (price != null) {
	            product.setPrice(price);
	        }
	    }

	    public void deleteProduct(String productId) {
	        if (!inventory.containsKey(productId)) {
	            throw new IllegalArgumentException("Product not found.");
	        }
	        inventory.remove(productId);
	    }

	    public Product getProduct(String productId) {
	        if (!inventory.containsKey(productId)) {
	            throw new IllegalArgumentException("Product not found.");
	        }
	        return inventory.get(productId);
	    }

	    public static void main(String[] args) {
	       Main ims = new Main();

	       
	        ims.addProduct(new Product("1", "Product A", 100, 10.0));
	        ims.addProduct(new Product("2", "Product B", 150, 15.0));

	  
	        ims.updateProduct("1", "Updated Product A", 120, 12.0);

	     
	        ims.deleteProduct("2");

	        System.out.println(ims.getProduct("1"));
	    }
	}


