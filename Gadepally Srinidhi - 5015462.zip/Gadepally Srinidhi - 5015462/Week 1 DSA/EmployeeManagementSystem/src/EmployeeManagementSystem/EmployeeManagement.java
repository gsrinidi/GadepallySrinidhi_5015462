package EmployeeManagementSystem;


public class EmployeeManagement {
    private Employee[] employees;
    private int size;
    private int capacity;

    public EmployeeManagement(int capacity) {
        this.capacity = capacity;
        this.employees = new Employee[capacity];
        this.size = 0;
    }

    public void addEmployee(Employee employee) {
        if (size == capacity) {
            System.out.println("Array is full. Cannot add more employees.");
            return;
        }
        employees[size++] = employee;
    }

    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    public void deleteEmployee(int employeeId) {
        int deleteIndex = -1;
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                deleteIndex = i;
                break;
            }
        }

        if (deleteIndex == -1) {
            System.out.println("Employee not found.");
            return;
        }

        for (int i = deleteIndex; i < size - 1; i++) {
            employees[i] = employees[i + 1];
        }

        employees[--size] = null; 
    }

    public static void main(String[] args) {
        EmployeeManagement management = new EmployeeManagement(5);

        Employee emp1 = new Employee(1, "Sri", "Manager", 90000);
        Employee emp2 = new Employee(2, "Nidhi", "Developer", 80000);
        Employee emp3 = new Employee(3, "Ishaan", "Designer", 70000);

        management.addEmployee(emp1);
        management.addEmployee(emp2);
        management.addEmployee(emp3);

        System.out.println("Traversing Employees:");
        management.traverseEmployees();

        System.out.println("\nSearching for Employee with ID 2:");
        Employee found = management.searchEmployee(2);
        System.out.println(found != null ? found : "Employee not found");

        System.out.println("\nDeleting Employee with ID 2:");
        management.deleteEmployee(2);
        management.traverseEmployees();
    }
}

