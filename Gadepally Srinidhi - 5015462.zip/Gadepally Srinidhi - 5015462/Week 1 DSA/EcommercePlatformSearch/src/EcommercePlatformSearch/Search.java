package EcommercePlatformSearch;

public class Search {
	
	    public static void main(String[] args) {
	        Product[] products = {
	            new Product("1", "Laptop", "Electronics"),
	            new Product("2", "Smartphone", "Electronics"),
	            new Product("3", "Table", "Furniture"),
	            new Product("4", "Chair", "Furniture"),
	            new Product("5", "Headphones", "Electronics")
	        };

	      
	        System.out.println("Linear Search Result:");
	        Product result = LinearSearch.linearSearch(products, "Table");
	        System.out.println(result != null ? result : "Product not found");

	       
	        System.out.println("\nBinary Search Result:");
	        result = BinarySearch.binarySearch(products, "Table");
	        System.out.println(result != null ? result : "Product not found");
	    }
	}

