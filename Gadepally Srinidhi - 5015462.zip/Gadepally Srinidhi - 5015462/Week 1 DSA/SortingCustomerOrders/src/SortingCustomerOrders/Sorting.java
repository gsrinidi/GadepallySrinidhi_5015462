package SortingCustomerOrders;

public class Sorting {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("1", "Sri", 150.0),
            new Order("2", "Nidhi", 90.0),
            new Order("3", "Dhruv", 200.0),
            new Order("4", "Tara", 120.0),
            new Order("5", "Dhara", 160.0)
        };

        System.out.println("Original Orders:");
        for (Order order : orders) {
            System.out.println(order);
        }

        BubbleSort.bubbleSort(orders);
        System.out.println("\nOrders after Bubble Sort:");
        for (Order order : orders) {
            System.out.println(order);
        }

       
        orders = new Order[]{
            new Order("1", "Sri", 150.0),
            new Order("2", "Nidhi", 90.0),
            new Order("3", "Dhruv", 200.0),
            new Order("4", "Tara", 120.0),
            new Order("5", "Dhara", 160.0)
        };

      
        QuickSort.quickSort(orders, 0, orders.length - 1);
        System.out.println("\nOrders after Quick Sort:");
        for (Order order : orders) {
            System.out.println(order);
        }
    }
}

