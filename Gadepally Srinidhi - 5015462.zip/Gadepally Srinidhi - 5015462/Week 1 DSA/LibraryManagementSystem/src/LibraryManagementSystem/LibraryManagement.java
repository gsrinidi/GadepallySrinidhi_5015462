package LibraryManagementSystem;
import java.util.*;

public class LibraryManagement {

    public static Book linearSearchByTitle(List<Book> books, String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public static Book binarySearchByTitle(List<Book> books, String title) {
 
        Collections.sort(books, Comparator.comparing(Book::getTitle));

        int left = 0;
        int right = books.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books.get(mid).getTitle().compareToIgnoreCase(title);

            if (comparison == 0) {
                return books.get(mid);
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        List<Book> books = new ArrayList<>();
        books.add(new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"));
        books.add(new Book(2, "To Kill a Mockingbird", "Harper Lee"));
        books.add(new Book(3, "1984", "George Orwell"));
        books.add(new Book(4, "Pride and Prejudice", "Jane Austen"));
        books.add(new Book(5, "The Catcher in the Rye", "J.D. Salinger"));

        System.out.println("Searching for '1984' using linear search:");
        Book foundBookLinear = linearSearchByTitle(books, "1984");
        System.out.println(foundBookLinear != null ? foundBookLinear : "Book not found");

        System.out.println("\nSearching for '1984' using binary search:");
        Book foundBookBinary = binarySearchByTitle(books, "1984");
        System.out.println(foundBookBinary != null ? foundBookBinary : "Book not found");

        System.out.println("\nSearching for 'The Great Gatsby' using linear search:");
        Book foundBookLinear2 = linearSearchByTitle(books, "The Great Gatsby");
        System.out.println(foundBookLinear2 != null ? foundBookLinear2 : "Book not found");

        System.out.println("\nSearching for 'The Great Gatsby' using binary search:");
        Book foundBookBinary2 = binarySearchByTitle(books, "The Great Gatsby");
        System.out.println(foundBookBinary2 != null ? foundBookBinary2 : "Book not found");

        System.out.println("\nSearching for 'Moby Dick' using linear search:");
        Book foundBookLinear3 = linearSearchByTitle(books, "Moby Dick");
        System.out.println(foundBookLinear3 != null ? foundBookLinear3 : "Book not found");

        System.out.println("\nSearching for 'Moby Dick' using binary search:");
        Book foundBookBinary3 = binarySearchByTitle(books, "Moby Dick");
        System.out.println(foundBookBinary3 != null ? foundBookBinary3 : "Book not found");
    }
}
