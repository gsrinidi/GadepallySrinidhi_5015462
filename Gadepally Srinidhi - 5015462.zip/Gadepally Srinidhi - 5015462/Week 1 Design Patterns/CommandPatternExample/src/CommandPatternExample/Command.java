package CommandPatternExample;

public interface Command {
    void execute();
}

