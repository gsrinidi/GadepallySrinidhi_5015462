package StrategyPatternExample;
public class Test {
	
	    public static void main(String[] args) {
	        PaymentContext paymentContext = new PaymentContext();

	        // Pay using Credit Card
	        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876-5432", "Dhruv Tara");
	        paymentContext.setPaymentStrategy(creditCardPayment);
	        paymentContext.executePayment(100.00);

	        System.out.println();

	        // Pay using PayPal
	        PaymentStrategy payPalPayment = new PayPalPayment("Dhruv.tara@example.com");
	        paymentContext.setPaymentStrategy(payPalPayment);
	        paymentContext.executePayment(200.00);
	    }
	}


