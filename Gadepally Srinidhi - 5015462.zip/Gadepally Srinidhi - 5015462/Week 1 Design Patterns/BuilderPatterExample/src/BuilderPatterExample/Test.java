package BuilderPatterExample;
public class Test {

	    public static void main(String[] args) {
	        Computer gamingComputer = new Computer.Builder()
	            .setCPU("Intel i9")
	            .setRAM("32GB")
	            .setStorage("1TB SSD")
	            .setGPU("NVIDIA RTX 3080")
	            .setMotherboard("ASUS ROG")
	            .setPowerSupply("750W")
	            .build();
	        
	        Computer officeComputer = new Computer.Builder()
	            .setCPU("Intel i5")
	            .setRAM("8GB")
	            .setStorage("256GB SSD")
	            .build();

	        System.out.println("Gaming Computer Configuration: " + gamingComputer);
	        System.out.println("Office Computer Configuration: " + officeComputer);
	    }
	

}
