package ObserverPatternExample;
public class Test {
	
	    public static void main(String[] args) {
	        StockMarket stockMarket = new StockMarket();

	        Observer mobileApp1 = new MobileApp("App1");
	        Observer mobileApp2 = new MobileApp("App2");
	        Observer webApp1 = new WebApp("WebApp1");

	        stockMarket.registerObserver(mobileApp1);
	        stockMarket.registerObserver(mobileApp2);
	        stockMarket.registerObserver(webApp1);

	        System.out.println("Setting stock price to 2000.00");
	        stockMarket.setStockPrice(2000.00);

	        System.out.println("\nDeregistering App2");
	        stockMarket.deregisterObserver(mobileApp2);

	        System.out.println("Setting stock price to 300000.00");
	        stockMarket.setStockPrice(300000.00);
	    }
	}


