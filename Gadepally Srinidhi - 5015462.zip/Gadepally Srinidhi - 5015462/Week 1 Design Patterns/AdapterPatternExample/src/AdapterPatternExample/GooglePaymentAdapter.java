package AdapterPatternExample;
public class GooglePaymentAdapter implements PaymentProcessor {
    private GooglePayment gp;
    public GooglePaymentAdapter(GooglePayment gp) {
        this.gp = gp;
    }
    public void processPayment(double amount) {
        gp.makePayment(amount);
    }
}

