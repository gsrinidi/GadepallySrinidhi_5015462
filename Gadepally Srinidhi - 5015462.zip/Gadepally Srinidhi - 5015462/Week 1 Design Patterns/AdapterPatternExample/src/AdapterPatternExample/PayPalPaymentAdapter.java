package AdapterPatternExample;
public class PayPalPaymentAdapter implements PaymentProcessor {
    private PayPalPayment payPalPayment;

    public PayPalPaymentAdapter(PayPalPayment payPalPayment) {
        this.payPalPayment = payPalPayment;
    }

    
    public void processPayment(double amount) {
        payPalPayment.sendPayment(amount);
    }
}

