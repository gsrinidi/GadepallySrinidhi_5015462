package AdapterPatternExample;
public class Test {
    public static void main(String[] args) {
        PaymentProcessor payPalProcessor = new PayPalPaymentAdapter(new PayPalPayment());
        payPalProcessor.processPayment(100.00);

        PaymentProcessor GooglePay = new GooglePaymentAdapter(new GooglePayment());
       GooglePay.processPayment(200.00);

        
    }
}

