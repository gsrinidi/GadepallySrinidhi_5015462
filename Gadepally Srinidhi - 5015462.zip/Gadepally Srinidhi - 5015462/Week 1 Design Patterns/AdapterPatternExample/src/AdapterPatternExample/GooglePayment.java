package AdapterPatternExample;

public class GooglePayment {
	    public void makePayment(double amount) {
	        System.out.println("Processing Google payment of $" + amount);
	    }

}
