package DecoratorPatternExample;
public class Test {
	
	    public static void main(String[] args) {
	        Notifier notifier = new EmailNotifier();
	        notifier.send("Hello, this is a basic email notification.");

	        System.out.println("\nAdding SMS notification:");
	        Notifier smsNotifier = new SMSNotifierDecorator(notifier);
	        smsNotifier.send("Hello, this is an email with SMS notification.");

	        System.out.println("\nAdding Slack notification:");
	        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);
	        slackNotifier.send("Hello, this is an email with SMS and Slack notifications.");
	    }
}
