package MVCPatternExample;
public class Main {
	
	    public static void main(String[] args) {
	     
	        Student student = new Student();
	        student.setName("Dhruv Sri");
	        student.setId("12345");
	        student.setGrade("A");

	   
	        StudentView view = new StudentView();

	    
	        StudentController controller = new StudentController(student, view);

	   
	        controller.updateView();

	 
	        controller.setStudentName("Tara Nidhi");
	        controller.setStudentGrade("B");

	        controller.updateView();
	    }
	}


